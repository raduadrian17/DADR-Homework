package ro.ucv.main;

public class MainClass {

	/**this is where you describe your class
	 * @param args
	 */
	public static void main(String[] args) {
	
		MainGUI m=new MainGUI();

	}

}
