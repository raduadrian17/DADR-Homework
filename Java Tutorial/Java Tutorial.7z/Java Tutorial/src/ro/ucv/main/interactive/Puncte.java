package ro.ucv.main.interactive;

public class Puncte {
	public int latitudine;
	public int longitudine;
	public int eticheta;
	
	public int getLongitudine()
	{
		return longitudine;
	}
	
	public int getLatitudine()
	{
		return latitudine;
	}
	
	public int getEticheta()
	{
		return eticheta;
	}
	
	public void setLongitudine(int longitudine)
	{
		this.longitudine=longitudine;
	}
	
	public void setLatitudine(int latitudine)
	{
		this.latitudine=latitudine;
	}
	
	public void setEticheta(int eticheta)
	{
		this.eticheta=eticheta;
	}

}
